﻿1.概要

ダウンロードしていただきありがとうございます。
『BP35A1_Wi-SUN_b-route_script.zip』は、ローム製の
無線モジュールBP35A1を動作させるためのツールです。
Tera Termマクロで作成しており、お客様の検討初期の
段階でおつかいいただくことでBP35A1の組込みを
スムーズに進めていただくことを目的として準備したものです。


2．内容物

・Wi-SUN-CORD.ttl
・Wi-SUN-SEND.ttl
・README.txt


3．使用環境

・WindowsPC　1台または2台
・BP35A1　2pcs
・BP35A7　2pcs
・BP359C　2pcs
・BP35A7accessory　2セット

環境のセッティングの詳細はロームのホームページに
掲載されている『bp35a1_startupmanual_ug-j.pdf』をご参照
ください。

BP35A1製品ページURL：
https://www.rohm.co.jp/products/wireless-communication/specified-low-power-radio-modules/bp35a1-product


4．動作概要

Wi-SUN-CORD.ttlはWi-SUNコーディネータとして動作します。
起動後はWi-SUNデバイスからのUDPパケットを待ちます。

Wi-SUN-SEND.ttlはWi-SUNデバイスとして動作します。
接続⇒UDP送信⇒切断を繰り返します。


以上
